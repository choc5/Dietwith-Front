import Ai_recomend from "./Ai_recomend"
export default Ai_recomend;